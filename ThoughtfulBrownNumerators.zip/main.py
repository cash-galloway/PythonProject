print("General Knowledge of the United States")
question1 = "How many stars does the US flag contain?"
options1 = "a.48\nb. 49\nc. 50\nd. 52\n"
print(question1)
print(options1)

while True:
    response1 = raw_input("Hit 'a', 'b', 'c' or 'd' for your answer\n")

    while response1 != "a"and response1!= "b"and response1!="c" and response1!="d":
      print ("Please select a, b, ,c, or d")
      response1 = raw_input("Hit 'a', 'b', 'c' or 'd' for your answer\n")
      
    if response1 == "c":
        print ("good job")
        break
     
    else:
        print("Incorrect!!! Try again.")
        
question2 = "What is the US’s national motto?"
options2 = "a.In god we trust\nb. Under god we trust\nc. Freedom\nd. Land of the Free\n"
print(question2)
print(options2)
        
while True:
    response2 = raw_input("Hit 'a', 'b', 'c' or 'd' for your answer\n")

    while response2 != "a"and response2!= "b"and response2!="c" and response2!="d":
      print ("Please select a, b, ,c, or d")
      response2 = raw_input("Hit 'a', 'b', 'c' or 'd' for your answer\n")
      
    if response2 == "a":
        print ("good job")
        break
    else:
        print("Incorrect!!! Try again.")
        
question3 = "What is the birthday of the US?"
options3 = "a.May 1, 1976\nb. July 4, 1977\nc. February 5, 1700\nd. July 4, 1776\n"
print(question3)
print(options3)
        
while True:
    response3 = raw_input("Hit 'a', 'b', 'c' or 'd' for your answer\n")
    while response3 != "a"and response3!= "b"and response3!="c" and response3!="d":
      print ("Please select a, b, ,c, or d")
      response3 = raw_input("Hit 'a', 'b', 'c' or 'd' for your answer\n")
      
    if response3 == "d":
        print ("good job")
        break
    else:
        print("Incorrect!!! Try again.")
        
question4 = "How much did Seward's purchase of Alaska cost?"
options4 = "a. $15 million\nb. $3 million\nc. $8.8 million\nd. $7.2 million\n"
print(question4)
print(options4)
        
while True:
    response4 = raw_input("Hit 'a', 'b', 'c' or 'd' for your answer\n")
    while response4 != "a"and response4!= "b"and response4!="c" and response4!="d":
      print ("Please select a, b, ,c, or d")
      response4 = raw_input("Hit 'a', 'b', 'c' or 'd' for your answer\n")
      
    if response4 == "d":
        print ("good job")
        break
    else:
        print("Incorrect!!! Try again.")
        
question5 = "Who had the longest tenure as President of USA?"
options5 = "a. John F. Kennedy\nb. Franklin D. Roosevelt\nc. George Washington\nd. James Carter\n"
print(question5)
print(options5)
        
while True:
    response5 = raw_input("Hit 'a', 'b', 'c' or 'd' for your answer\n")
    while response5 != "a"and response5!= "b"and response5!="c" and response5!="d":
      print ("Please select a, b, ,c, or d")
      response5 = raw_input("Hit 'a', 'b', 'c' or 'd' for your answer\n")
      
    if response5 == "b":
        print ("good job")
        break
    else:
        print("Incorrect!!! Try again.")
        
question6 = "What are the two major political parties in the US?"
options6 = "a. Democrats and Republicans\nb. Liberals and Conservatives\nc. Democrats and Green Party\nd. Green Party and Conservatives\n"
print(question6)
print(options6)
        
while True:
    response6 = raw_input("Hit 'a', 'b', 'c' or 'd' for your answer\n")
    while response6 != "a"and response6!= "b"and response6!="c" and response6!="d":
      print ("Please select a, b, ,c, or d")
      response6 = raw_input("Hit 'a', 'b', 'c' or 'd' for your answer\n")
      
    if response6 == "b":
        print ("good job")
        break
    else:
        print("Incorrect!!! Try again.")
        
question7 = "In which year man stepped on the Moon for the first time?"
options7 = "a. 1969\nb. 1975\nc. 1962\nd. 1957\n"
print(question7)
print(options7)
        
while True:
    response7 = raw_input("Hit 'a', 'b', 'c' or 'd' for your answer\n")
    while response7 != "a"and response7!= "b"and response7!="c" and response7!="d":
      print ("Please select a, b, ,c, or d")
      response7 = raw_input("Hit 'a', 'b', 'c' or 'd' for your answer\n")
      
    if response7 == "a":
        print ("good job")
        break
    else:
        print("Incorrect!!! Try again.")
        
question8 = "How many branches of government are there in the US?"
options8 = "a. 1\nb. 2\nc. 3\nd. 4\n"
print(question8)
print(options8)
        
while True:
    response8 = raw_input("Hit 'a', 'b', 'c' or 'd' for your answer\n")
    while response8 != "a"and response8!= "b"and response8!="c" and response8!="d":
      print ("Please select a, b, ,c, or d")
      response8 = raw_input("Hit 'a', 'b', 'c' or 'd' for your answer\n")
      
    if response8 == "c":
        print ("good job")
        break
    else:
        print("Incorrect!!! Try again.")
        
question9 = "How many voting members of the house of representatives are there?"
options9 = "a. 500\nb. 345\nc. 435\nd. 438\n"
print(question9)
print(options9)
        
while True:
    response9 = raw_input("Hit 'a', 'b', 'c' or 'd' for your answer\n")
    while response9 != "a"and response9!= "b"and response9!="c" and response9!="d":
      print ("Please select a, b, ,c, or d")
      response9 = raw_input("Hit 'a', 'b', 'c' or 'd' for your answer\n")
      
    if response9 == "c":
        print ("good job")
        break
    else:
        print("Incorrect!!! Try again.")
    
question10 = "How many justices are there in the supreme court??"
options10 = "a. 9\nb. 13\nc. 7\nd. 5\n"
print(question10)
print(options10)
        
while True:
    response10 = raw_input("Hit 'a', 'b', 'c' or 'd' for your answer\n")
    while response10 != "a"and response10!= "b"and response10!="c" and response10!="d":
      print ("Please select a, b, ,c, or d")
      response10 = raw_input("Hit 'a', 'b', 'c' or 'd' for your answer\n")
      
    if response10 == "a":
        print ("good job! The quiz is officially over.")
        break
    else:
        print("Incorrect!!! Try again.")